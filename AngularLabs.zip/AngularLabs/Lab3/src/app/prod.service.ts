import { Injectable } from '@angular/core';
import { Product } from './product-form/product';

@Injectable({
  providedIn: 'root'
})
export class ProdService {

  constructor() { }

  sendDataToExternalProgram(product:Product){
    console.log(product);
  }
}
