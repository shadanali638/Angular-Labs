export class Product
{
    constructor(private prodId:number,private prodName:string,private prodCost:number,private prodOnline:string,private prodCategory:string,private prodAvail:string){
        this.prodId=prodId;
        this.prodName=prodName;
        this.prodCost=prodCost;
        this.prodOnline=prodOnline;
        this.prodCategory=prodCategory;
        this.prodAvail=prodAvail;
    }
}