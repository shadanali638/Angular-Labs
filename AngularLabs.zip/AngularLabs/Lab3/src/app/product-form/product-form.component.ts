import { Component, OnInit } from '@angular/core';
import { Product } from './product';
import { ProdService } from '../prod.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-product-form',
  templateUrl: './product-form.component.html',
  styleUrls: ['./product-form.component.css']
})
export class ProductFormComponent implements OnInit {

    products:string[]=['Bakery','Mobile','Electronics','Cloths'];
    pproduct:any=new Product(100,'Laptop',74000,'','Smart Devices','');
    isSubmitted = false;
constructor(private productService:ProdService) {
   }
   
  ngOnInit(): void {
  }
  saveData(){
    this.productService.sendDataToExternalProgram(this.pproduct);
  }

  

}
