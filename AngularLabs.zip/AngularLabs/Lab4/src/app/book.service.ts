import { Injectable } from '@angular/core';
import {HttpClient, HttpErrorResponse} from '@angular/common/http';
import { Observable } from 'rxjs';

import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { Book } from './book/book';
@Injectable({
  providedIn: 'root'
})
export class BookService {
  dataUrl:string="./assets/booklist.json";

  constructor(private httpService:HttpClient) { }

  getBooks():Observable<Book[]>
{
  return this.httpService.get<Book[]>(this.dataUrl).catch(this.errorHandler);
}
errorHandler(error:HttpErrorResponse)
{
  return Observable.throw(error.message);

}


}
