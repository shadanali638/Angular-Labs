import { Component, OnInit, Output } from '@angular/core';


@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
  id:number;
  name:string;
  salary:number;
  department:string;
  estatus:boolean=false;
  result:string;

  constructor(){
    
   }

   
  ngOnInit(): void {
  }

 employeeDetails:Array<{id:number,name:string,salary:number,department:string}>=[
   {id:101,name:"Shadan",salary:45000,department:"MCA"},
   {id:102,name:"Shubham",salary:35000,department:"MCA"},
   {id:103,name:"Alok",salary:55000,department:"MCA"},
 ];

 

 delete(id:number)
{
  for (let i = this.employeeDetails.length - 1; i>= 0; i--) {
      if (this.employeeDetails[i].id === id) {
          this.employeeDetails.splice(i, 1);
      }
  }
  alert("Data Deleted");
}
  addEmployee(arg1:any,arg2:any,arg3:any,arg4:any){
    this.id=parseInt((<HTMLInputElement>arg1).value);
    this.name=(<HTMLInputElement>arg2).value;
    this.salary=parseInt((<HTMLInputElement>arg3).value);
    this.department=(<HTMLInputElement>arg4).value;
  
    this.employeeDetails.push({id:this.id,name:this.name,salary:this.salary,department:this.department})
    
    this.estatus=true;
    
    if(this.estatus==true){
      alert(this.id+" "+this.name+" "+this.salary+" "+this.department);
    }
    else{
      this.result="";
    }
    

  }
 


  newid:number;
  newname:string;
  newsalary:number;
  newdepartment:string;
  update(id:number,name:string,salary:number,department:string)
  {
    this.newid=id;
    this.newname=name;
    this.newsalary=salary;
    this.newdepartment=department;
  }  
  editrow(id:number,name:string,salary:number,department:string)
  {
    for(let i=0;i<this.employeeDetails.length;i++){
      let e=this.employeeDetails[i];
      if(e.id==id){
        console.log(name);
        this.employeeDetails.splice(i,1);  
        this.employeeDetails.push({id,name,salary,department});
        console.log(e.name);
        break;
      }
  }
  alert("Row Updated");
  }
}
